#include "maarjaan.h";

//this function will sort players by their scores and the prints table of scores
void score_table(player* players_array,int number_of_players){ 
    for(int i = 0 ; i < number_of_players ; i++){
        for(int j = 0 ; j  < number_of_players - i - 1 ; j++){
            if(players_array[j].score < players_array[j+1].score ){
                char temp[50];
                int temp_s = players_array[j].score ;
                players_array[j].score = players_array[j+1].score;
                players_array[j+1].score = temp_s;
                strcpy(temp,players_array[j].name);
                strcpy(players_array[j].name , players_array[j+1].name);
                strcpy(players_array[j+1].name,temp);
            }
        }
    }
    for(int i = 0 ; i < number_of_players ; i++){
        cout<<i+1<<'.'<<players_array[i].name<<" :"<<' '<<players_array[i].score<<endl;
    }
}

/*
*in the function below we are intended to find a username in an array of players 
*the function returns the index if it exists in the array an will return -1 if not 
*further in main function we need this function for processing strings of usernames
*/
int find_player(char* person , int number_of_players, player* players_array){
    for(int i = 0 ; i < number_of_players ; i++){
        if(strcmp(person,players_array[i].name) == 0){
            return i;
        }
    }
    return -1;
}

//defining a function to create a frame of the game 
void create_frame (int row , int col){
	unsigned int off = 5 ;
	cursor_to_pos(1,1);
	cout<<"maarjaan -by Haami Jahanian";
	cursor_to_pos(2,6);
    change_color_rgb(244,164,96);
	for(int i = 0 ; i < col  ; i++ )
		cout<<'_';
	cursor_to_pos(row, 6);
	for(int i = 0 ; i < col ; i++ )
		cout<<'_';
	for(int i = 0 ; i < row -2 ; i++ ){
		cursor_to_pos(i + 3,6);
		cout<<'*';
	}
	for(int i = 0 ; i < row -2 ; i++ ){
		cursor_to_pos(i + 3, col + 5);
		cout<<'*';
	}
    change_color_rgb(255,255,255);
}

/*
* defining a function for moving the snake forward to continue it's way (without apples)(temporary!!!!!!!!)
* note that in this project we can model the snake as a train 
* in a train, when the train turns the direction of wagons will be shifted from the begining till the end
* in other words all the wagons will inherit the motion  of the first wagon so for analysing motion of a train 
* you can just move the first wagon and then copy direction and place of every wagon from the begining till the end
* in the function below we have used this method to model the snake like a train and analysing it's motion  
*/
void continue_way(snake& state){
	snake_point* current_points_array = new snake_point[state.len - 1];
	for(int i = 0 ; i < state.len - 1 ; i++){
		current_points_array[i].direction = state.snake_body[i].direction;
		current_points_array[i].y = state.snake_body[i].y;
		current_points_array[i].x = state.snake_body[i].x;
	}
	if(state.snake_body[0].direction == Up ){
			state.snake_body[0].y --;
		}
		else if(state.snake_body[0].direction == Down){
			state.snake_body[0].y ++;
		}
		else if(state.snake_body[0].direction == Right){
			state.snake_body[0].x ++;
		}
		else{
			state.snake_body[0].x --;
		} 
	for(int i = 0 ; i < state.len - 1 ; i++){
		state.snake_body[i+1].direction = current_points_array[i].direction;
		state.snake_body[i+1].y = current_points_array[i].y;
		state.snake_body[i+1].x = current_points_array[i].x;
	}
	//deleting the array to avoid memory leak
	delete [] current_points_array;
}

/*
* in the function below we are intended to move the snake not just forward in it's way 
* the basic theory here is that for any valid command that changes the direction of the snake's head we can model this as follows
* the command changes the snake's head direction and then it countinues it's way with the function above 
*/
//defining a function to move the snake 
snake move_snake_1(snake & situation , char command ){
	if(situation.snake_body[0].direction == Up || situation.snake_body[0].direction == Down){
		//first we are gonna see whether the command will affect the snake or not in this particular situation 
		if(command == 'w' || command == 's'){
			continue_way(situation);
		}
		//then we will continue with considering another situations 
		else if(command == 'a'){
			situation.snake_body[0].direction = Left;
			continue_way(situation);
		}
		else if(command == 'd'){
			situation.snake_body[0].direction = Right;
			continue_way(situation);
		}
		else{
			continue_way(situation);
		}
	}
	else{
		//first we are gonna see whether the command will affect the snake or not in this particular situation 
		if(command == 'd' || command == 'a'){
			continue_way(situation);
		}
		//then we will continue with considering another situations
		else if(command == 's'){
			situation.snake_body[0].direction = Down;
			continue_way(situation);
		}
		else if(command == 'w'){
			situation.snake_body[0].direction = Up;
			continue_way(situation);
		}
		else{
			continue_way(situation);
		}
	}
	return situation;
}

//defining a function to move the second snake
snake move_snake_2(snake & situation , char command){
    if(situation.snake_body[0].direction == Up || situation.snake_body[0].direction == Down){
		//first we are gonna see whether the command will affect the snake or not in this particular situation 
		if(command == '8' || command == '5'){
			continue_way(situation);
		}
		//then we will continue with considering another situations 
		else if(command == '4'){
			situation.snake_body[0].direction = Left;
			continue_way(situation);
		}
		else if(command == '6'){
			situation.snake_body[0].direction = Right;
			continue_way(situation);
		}
		else{
			continue_way(situation);
		}
	}
	else{
		//first we are gonna see whether the command will affect the snake or not in this particular situation 
		if(command == '6' || command == '4'){
			continue_way(situation);
		}
		//then we will continue with considering another situations
		else if(command == '5'){
			situation.snake_body[0].direction = Down;
			continue_way(situation);
		}
		else if(command == '8'){
			situation.snake_body[0].direction = Up;
			continue_way(situation);
		}
		else{
			continue_way(situation);
		}
	}
	return situation;
}

/////defining a function to print the snake's body after motion analysis
void print_screen(snake s_1 , snake s_2 , playground yard){
    clear_screen();
	create_frame(20,40);
	//printing first snake's body 
	//change_color_rgb 
    if(has_lost[0] == 0){
        change_color_rgb(0,255,255);                
        for(int i  = 0 ; i < s_1.len ; i++){
            cursor_to_pos(2 + s_1.snake_body[i].y , 6 + s_1.snake_body[i].x);
            if(i == 0){
                cout<<'O';
            }
            else{
			
                cout<<'*';
            }
        }
    }
	//printing second snake's body 
	//change_color_rgb 
    if(has_lost[1] == 0){
        change_color_rgb(0,255,0);
        for(int i  = 0 ; i < s_2.len ; i++){
            cursor_to_pos(2 + s_2.snake_body[i].y , 6 + s_2.snake_body[i].x);
            if(i == 0){
                
                cout<<'O';
            }
            else{
                cout<<'*';
            }
        }
    }
	//printing apples
	//change_color_rgb 
	for(int i = 0 ; i < yard.number_of_apples ; i++){
		cursor_to_pos(2 + yard.apples_array[i].y , 6 + yard.apples_array[i].x);
        change_color_rgb(0,255,0);
		cout<<'a';
	}
	//printing bombs 
	//change_color_rgb 
	for(int i = 0 ; i < yard.number_of_bombs ; i++){
		cursor_to_pos(2 + yard.bombs_array[i].y , 6 + yard.bombs_array[i].x);
        change_color_rgb(255,0,0);
		cout<<'b';
	}
    change_color_rgb(255,255,255);
}

//defining a function to generate apples in the playground 
playground add_apple( playground& yard, snake s_1 , snake s_2){
	srand(time(NULL));
	int new_apple_x = (rand() % 35) + 2;
	int new_apple_y = (rand() % 16) + 2;
	int is_valid_1 = 1;
	int is_valid_2 = 1;
	int is_apple_valid = 1;
	//checking that the apple lies on the first snake's body or not 
	for(int i = 0 ; i < s_1.len ; i++){
		if( new_apple_x == s_1.snake_body[i].x && new_apple_y == s_1.snake_body[i].y){
			is_valid_1 = 0;
			break;
		}
		else{
			continue;
		}
	}
	//checkint that the apple lies on the second snake's body or not
	for(int i = 0 ; i < s_2.len ; i++){
		if( new_apple_x == s_2.snake_body[i].x && new_apple_y == s_2.snake_body[i].y){
			is_valid_2 = 0;
			break;
		}
		else{
			continue;
		}
	}
	//
	if( (is_valid_1 == 1) && (is_valid_2 == 1) ){
		//this loop will check whether the apple lies on other apples or not
		for( int i = 0; i < yard.number_of_apples ; i++){
			if( new_apple_x == yard.apples_array[i].x && new_apple_y == yard.apples_array[i].y){
				is_apple_valid = 0;
				break;
			}
			else{
				continue;
			}
		}
		//this loop checks whether the apple lies on bombs or not
		for( int i = 0; i < yard.number_of_bombs ; i++){
			if( new_apple_x == yard.bombs_array[i].x && new_apple_y == yard.bombs_array[i].y){
				is_apple_valid = 0;
				break;
			}
			else{
				continue;
			}
		}
		if(is_apple_valid == 1){
			yard.apples_array[yard.number_of_apples].x = new_apple_x;
			yard.apples_array[yard.number_of_apples].y = new_apple_y;
			yard.number_of_apples ++;
			return yard;
		}
		else{
			return yard;
		}
	}
	else{
		return yard;
	}
}

//defining a function to genereta bombs in the playground 
playground add_bomb( playground& yard, snake s_1, snake s_2){
	srand(time(NULL));
	int new_bomb_x = (rand() % 35) + 2;
	int new_bomb_y = (rand() % 16) + 2;
	int is_valid_1 = 1;
	int is_valid_2 = 1; 
	int is_bomb_valid = 1;
	//this loop checks whether the bomb lies on the first snake or not 
	for(int i = 0 ; i < s_1.len ; i++){
		if( new_bomb_x == s_1.snake_body[i].x && new_bomb_y == s_1.snake_body[i].y){
			is_valid_1 = 0;
			break;
		}
		else{
			continue;
		}
	}
	//this loop checks whether the bomb lies on the second snake or not
	for(int i = 0 ; i < s_2.len ; i++){
		if( new_bomb_x == s_2.snake_body[i].x && new_bomb_y == s_2.snake_body[i].y){
			is_valid_2 = 0;
			break;
		}
		else{
			continue;
		}
	}
	if( (is_valid_1 == 1) && (is_valid_2 == 1)){
		//this loop checks whether new bomb lies on apples or not
		for( int i = 0; i < yard.number_of_apples ; i++){
			if( new_bomb_x == yard.apples_array[i].x && new_bomb_y == yard.apples_array[i].y){
				is_bomb_valid = 0;
				break;
			}
			else{
				continue;
			}
		}
		//this loop checks whether the bomb lies on other bombs or not 
		for( int i = 0; i < yard.number_of_bombs ; i++){
			if( new_bomb_x == yard.bombs_array[i].x && new_bomb_y == yard.bombs_array[i].y){
				is_bomb_valid = 0;
				break;
			}
			else{
				continue;
			}
		}
		if(is_bomb_valid == 1){
			yard.bombs_array[yard.number_of_bombs].x = new_bomb_x;
			yard.bombs_array[yard.number_of_bombs].y = new_bomb_y;
			yard.number_of_bombs ++;
			return yard;
		}
		else{
			return yard;
		}
	}
	else{
		return yard;
	}
}

/*
* in the following function has_hit_bomb variable has defined to check whether the snake has hit a bomb or not 
*/
//defining a function to check that the user has lost the game or not 
int checkforloss(snake s , playground yard, int snake_number){
    if(has_lost[snake_number] == 0){
        int has_hit_bomb = 0;
        for(int i = 0 ; i < yard.number_of_bombs ; i++){
            if( s.snake_body[0].x == yard.bombs_array[i].x && s.snake_body[0].y == yard.bombs_array[i].y ){
                has_hit_bomb = 1;
				//Beep
            }
            else{
                continue;
            }
        }
        //first losing by hitting margins or by hitting snake's body
        if(has_hit_bomb == 0 ){
            if(s.snake_body[0].x <1 || s.snake_body[0].x >38 ){
                //has_lost[snake_number] = 1;
                return 0 ;
				//Beep
            }
            else if(s.snake_body[0].y < 1 || s.snake_body[0].y > 18 ){
               // has_lost[snake_number] = 1;
               return 0;
				//Beep
            }
            else{
                for(int i = 1 ; i < s.len ; i ++){
                    if( (s.snake_body[0].x == s.snake_body[i].x) && (s.snake_body[0].y == s.snake_body[i].y) ){
                        //has_lost[snake_number] = 1;
                        clear_screen();
                        return 0 ;
						//Beep
                    }
                }
               // has_lost[snake_number] = 0;
               return 1;
            }
        }
        //then losing by hitting bombs
        else{
            //has_lost[snake_number] = 1;
            return 0;
        }
    }
    //else{
     //   return ;
   // }
}

//defining a function to add the length of snake after eating an apple
void add_length(snake &s, playground &yard){
	int has_eaten_apple = 0;
	int apple_cnt;
	for(int i = 0 ; i < yard.number_of_apples ; i++){
		if( (s.snake_body[0].x == yard.apples_array[i].x) && (s.snake_body[0].y == yard.apples_array[i].y) ){
			has_eaten_apple =1;
			//Beep
			apple_cnt = i;
			break;
		}
	}
	if(has_eaten_apple == 1){
        Beep(400,10);
		s.len ++;
		s.snake_body[s.len - 1].direction = s.snake_body[s.len - 2].direction; 
		if( s.snake_body[s.len - 2].direction == Up ){
			s.snake_body[s.len - 1].x = s.snake_body[s.len - 2].x;
			s.snake_body[s.len - 1].y = s.snake_body[s.len - 2].y + 1;
		}
		else if( s.snake_body[ s.len - 2].direction == Down ){
			s.snake_body[s.len - 1].x = s.snake_body[s.len - 2].x ;
			s.snake_body[s.len - 1].y = s.snake_body[s.len - 2].y - 1;
		}
		else if( s.snake_body[s.len - 2].direction == Right ){
			s.snake_body[s.len - 1].x = s.snake_body[s.len - 2].x - 1;
			s.snake_body[s.len - 1].y = s.snake_body[s.len - 2].y;
		}
		else{
			s.snake_body[s.len - 1].x = s.snake_body[s.len - 2].x + 1;
			s.snake_body[s.len - 1].y = s.snake_body[s.len - 2].y;
		}
		for(int i = apple_cnt  ; i < yard.number_of_apples - 1 ; i++ ){
			yard.apples_array[i].x = yard.apples_array[i+1].x;
			yard.apples_array[i].y = yard.apples_array[i+1].y;
		}
		
		yard.number_of_apples --;
	}
}

//defining a function to initialize snakes
void init_snake(snake & s ,int length , int starting_x , int starting_y){
	s.len = length;
	s.snake_body[0].x = starting_x + 3;
	s.snake_body[1].x = starting_x + 2;
	s.snake_body[2].x = starting_x + 1;
	s.snake_body[3].x = starting_x;
	s.snake_body[0].y = starting_y;
	s.snake_body[1].y = starting_y;
	s.snake_body[2].y = starting_y;
	s.snake_body[3].y = starting_y;
	for(int i = 0 ; i < 3 ; i++){
		s.snake_body[i].direction = Right;
	}
}

/*
*in the following function return value 0 means we had no collision 
* 12 means the first snake hit the second snake
* 21 means the second snake hit the first snake 
* 11 means a head in head collision 
*/
//defining a function to determine whether two snakes had an intersect or not and if yes how is the intersect 
int intersect(snake s_1 , snake s_2){
    int has_hit_1 = 0;
    int has_hit_2 = 0;
    //this loop will see that if the first snake has hit another one or not 
    for(int i = 0 ; i < s_2.len ; i++){
        if( (s_1.snake_body[0].x == s_2.snake_body[i].x) && (s_1.snake_body[0].y == s_2.snake_body[i].y) ){
            has_hit_1 = 1;
			//Beep
        } 
    } 
    //this loop will see that if the second snake has hit another on or not 
    for(int i = 0 ; i < s_1.len ; i++){
        if( (s_2.snake_body[0].x == s_1.snake_body[i].x) && (s_2.snake_body[0].y == s_1.snake_body[i].y) ){
            has_hit_2 = 1;
			//Beep
        } 
    } 
    //then we will determine the situation 
    if( (has_hit_2 == 0) && (has_hit_1 == 0) ){
        return 0 ;
    }
    else if( (has_hit_2 == 0) && (has_hit_1 == 1) ){
        return 12;
    }
    else if((has_hit_2 == 1) && (has_hit_1 == 0)){
        return 21;
    }
    else{
        return 11;
    }

}

//defining a function to eliminate snakes after losing the game 
void eliminate_snake(snake & s){
    for(int i = 0 ; i < s.len ;i++ ){
        s.snake_body[i].x = -1;
        s.snake_body[i].y = -1;
    }
}

//defining a function to print instructions before loading the game 
void loading_page(){
    clear_screen();
    change_color_rgb(255,0,0);
    cout<< "pay attention"<<endl;
    change_color_rgb(0,255,0);
    cout<<"first player's snake is in blue and other one is in green"<<endl;
    change_color_rgb(255,0,0);
    cout<<"controls:"<<endl;
    cout<<"---------------------------------------------------------------------"<<endl;
    change_color_rgb(0,255,0);
    cout<<"first snake :"<<endl;
    cout<<"going up : w "<<endl;
    cout<<"going down : s "<<endl;
    cout<<"going right : d"<<endl;
    cout<<"going left : a"<<endl;
    cout<<"------------------------"<<endl;
    cout<<"second snake : "<<endl;
    cout<<"going up : 8"<<endl;
    cout<<"going down : 5"<<endl;
    cout<<"going left : 4"<<endl;
    cout<<"going right : 6"<<endl;
    Sleep(10000);
    clear_screen();
}
//main function
int main(){
    //intializing clui library 
	init_clui();
    //declaration level
    player players_array[100];
    int number_of_players = 0 ;
    for(;;){
        // main menu 
        change_color_rgb(0,0,255);
        cout<<"main menu :"<<endl;
        cout<<"------------------------------------------------------------"<< endl;
        change_color_rgb(255,255,0);
        cout<<'P';
        change_color_rgb(0,0,255);
        cout<<"lay game  "<<endl;
        change_color_rgb(255,255,0);
        cout<<'C';
        change_color_rgb(0,0,255);
        cout<<"hange username "<<endl;
        change_color_rgb(255,255,0);
        cout<<'S';
        change_color_rgb(0,0,255);
        cout<<"how scores table"<<endl;
        change_color_rgb(255,255,0);
        cout<<'E';
        change_color_rgb(0,0,255);
        cout<<"xit game"<<endl;
        cout<<"Enter your option from one of those characters in yellow"<<endl;
        char option;
        cin>>option;
        if((option == 'C') || (option == 'c')){
            char current_username[50];
            char second_username[50];
            char farib[1];
            cout<< "enter the username that you want to change :";
            cin.getline(farib,1);
            cin.getline(current_username,50);
            if(find_player(current_username,number_of_players,players_array) == -1){
                cout<<"INVALID USERNAME"<<endl;
                Sleep(2000);
                clear_screen();
            }
            else{
                int i = find_player(current_username,number_of_players,players_array);
                cout<<"enter your new username :";
                cin.getline(second_username,50);
                strcpy(players_array[i].name,second_username);
                cout<<"username changed successfully";
                Sleep(2000);
                clear_screen();
            }
        }
        else if ((option == 'S') || (option == 's')){
            clear_screen();
            score_table(players_array,number_of_players);
            char escape;
            cout<<"enter any character go to main menu"<<endl;
            char exit_option;
            cin>>exit_option;
            clear_screen();
        }
        else if((option == 'E') || (option == 'e')){
            clear_screen();
            cout<<"are you sure ?"<<endl;
            change_color_rgb(255,255,0);
            cout<<'Y';
            change_color_rgb(0,0,255);
            cout<<"es"<<endl;
            change_color_rgb(255,255,0);
            cout<<'N';
            change_color_rgb(0,0,255);
            cout<<'o'<<endl;
            char exit_option ;
            cin>>exit_option;
            if(exit_option == 'Y'){
                return 0;
            }
            else {
                clear_screen();
            }
        }
        else if( (option == 'P') || (option == 'p') ){
            //declaring variables that are needed to processing strings
            player first_player , second_player;
            int first_player_index ,second_player_index;
            char deception[50];
            int first_score  , second_score;
            //processing strings of players' names
            clear_screen();
            cout<< "please enter the first player username :" ;
            cin.getline(deception,50);
            cin.getline(first_player.name ,50);
            cout<< "please enter the second player username :";
            cin.getline(second_player.name ,50);
            if( find_player( first_player.name,number_of_players,players_array) == -1 ){
                first_player_index = number_of_players;
                strcpy(players_array[first_player_index].name,first_player.name);
                number_of_players ++;
            }
            else{
                first_player_index = find_player( first_player.name,number_of_players,players_array);
            }
            if( find_player( second_player.name,number_of_players,players_array) == -1 ){
                second_player_index = number_of_players;
                strcpy(players_array[second_player_index].name,second_player.name);
                number_of_players ++;
            }
            else{
                second_player_index = find_player( second_player.name,number_of_players,players_array);
            }
            loading_page();
            //declaration level
            change_color_rgb(255,255,255);
            char current_command_1, current_command_2 ;
            char current_command;
            snake snake_1;
            snake snake_2;
            playground yard;
            //initiating the playground
            yard.number_of_apples = 0;
            yard.number_of_bombs = 0;
            //creating snakes by initializing the snake struct that defined above 
            init_snake(snake_1,4,7,3);
            init_snake(snake_2,4,7,4);
            //initializing the screen
            clear_screen();
            create_frame(20, 40);
            print_screen(snake_1, snake_2 , yard) ; 
            for(;;){
                int mean;
                int a , b;
                //generating bomb and apple
                if(mean<5){
                    a = 25;
                    b = 10;
                }
                else if(5<=mean<10){
                    a = 35;
                    b = 7;
                }
                else{
                    a = 40;
                    b = 5;
                }
                srand(time(NULL));
                int random_1 = rand() % b;
                int random_2 = rand() % a;
                if(random_1 == 0 || random_1 == 1 || random_1 == 2){
                    add_apple(yard, snake_1, snake_2);
                }
                else if(random_1 == 5 ){
                    add_bomb(yard,snake_1,snake_2);
                }
                //getting commands 
                if(is_keyboard_hit() == true  ){
                    current_command = getch();
                    if((current_command == 'w') || (current_command == 'd') || (current_command == 's') || (current_command == 'a')){
                        current_command_1 = current_command;
                        current_command_2 = 'c';
                    }
                    else if((current_command == '8') || (current_command == '4') || (current_command == '5') || (current_command == '6')){
                        current_command_2 = current_command;
                        current_command_1 = 'c';
                    }
                    else{
                        current_command_1 = 'c';
                        current_command_2 = 'c';
                        Beep(1000,500);     
                    }
                }
                else{
                    current_command_1 = 'c';
                    current_command_2 = 'c';
                }
                //moving snakes
                if(has_lost[0] == 0){
                    move_snake_1(snake_1,current_command_1);
                    add_length(snake_1,yard);
                }
                if(has_lost[1] == 0){
                    move_snake_2(snake_2,current_command_2);  
                    add_length(snake_2,yard);
                }
                //analysing situation 
                if( intersect(snake_1,snake_2)== 21){ 
                    has_lost[1] = 1;
                    Beep(150,500);
                    cursor_to_pos(1,1);
                    cout<<players_array[second_player_index].name<<" lost"<<endl;
                    Sleep(800);
                    clear_screen();
                    eliminate_snake(snake_2);
                }   
                else if(intersect(snake_1,snake_2)== 12) {
                    has_lost[0] = 1;
                    Beep(150,500);
                    cursor_to_pos(1,1);
                    cout<<players_array[first_player_index].name<<" lost"<<endl;
                    Sleep(800);
                    clear_screen();
                    eliminate_snake(snake_1);
                }
                //the following one means a head in head collision between two snakes  
                else if(intersect(snake_1,snake_2) == 11 ){
                        has_lost[0] = 1;
                        has_lost[1] = 1;
                        Beep(150,500);
                        cursor_to_pos(1,1);
                        cout<<"both players lost the game";
                        Sleep(2000);
                        clear_screen();
                        eliminate_snake(snake_2);
                        eliminate_snake(snake_1);
                }
                if(checkforloss(snake_1,yard,0) == 0){
                    has_lost[0] = 1;
                    Beep(150,500);
                    Sleep(300);
                    cursor_to_pos(1,1);
                    cout<<players_array[first_player_index].name<<" lost"<<endl;
                    Sleep(800);
                    clear_screen();
                    eliminate_snake(snake_1);
                };//should be written 
                if(checkforloss(snake_2,yard,1) == 0){
                    has_lost[1] = 1;
                    Beep(150,500);
                    Sleep(300);
                    cursor_to_pos(1,1);
                    cout<<players_array[second_player_index].name<<" lost"<<endl;
                    Sleep(800);
                    clear_screen();
                    eliminate_snake(snake_2);
                };
                //determine whether the game is finished or not  
                if( (has_lost[1] == 1) &&  (has_lost[0] == 1) ){
                    Sleep(3000);
                    clear_screen();
                    cursor_to_pos(1,1);
                    //cout<<"player 1 won the game";
                    clear_screen();
                    if(first_score > second_score){
                        cout<<players_array[first_player_index].name<<" won"<<endl;    
                        Sleep(3000);
                        clear_screen();
                    }
                    else if(first_score < second_score){
                        cout<<players_array[second_player_index].name<<" won"<<endl;    
                        Sleep(3000);
                        clear_screen();
                    }
                    else{
                        cout<<"no one won the game"<<endl;    
                        Sleep(3000);
                        clear_screen();
                    }
                    players_array[first_player_index].score += first_score;
                    players_array[second_player_index].score += second_score;
                    has_lost[0] = 0;
                    has_lost[1] = 0;
                    break;
                }
                else{
                    int delay;
                    if(mean < 5){
                        Sleep(100);
                    }
                    else if(5<= mean < 10){
                        Sleep(50);
                    }
                    else{
                        Sleep(20);
                    }
                    print_screen(snake_1,snake_2,yard);
                    second_score = snake_2.len - 4;
                    first_score = snake_1.len - 4;
                    mean = (first_score + second_score) / 2 ;
                    cursor_to_pos(22,3);
                    cout<<players_array[first_player_index].name<<" score : "<<first_score<<endl;
                    cursor_to_pos(22,36);
                    cout<<players_array[second_player_index].name<<" score : "<<second_score<<endl;
               }
            }
        }
        else{
            cout<<"INVALID COMMAND"<<endl;
            Sleep(1000);
        	clear_screen();
        }    
    } 
}