#include<iostream> //for basic operations 
#include "clui.h" //this is used for command line graphical works and better interface
#include <time.h> //for generating sudo_random numbers for bombs and apples 
using namespace std;
// direction of snake body elements
enum dir {Up, Left, Down, Right};

//defingin a stuct for the snake's body parts
struct snake_point {
	int x ; 
	int y ; 
	enum dir direction;
}; 

//defining a struct for the whole snake's body with all of it's details 
struct snake {
	snake_point snake_body [800];
	int len;
};

//defining a struct for apples 
struct apple{
	int x ; 
	int y ; 
};

//defining a struct for bombs 
struct bomb {
	int x ;
	int y; 
};

//defining a struct for saving details of the playgrond 
struct playground{
	bomb bombs_array [100];
	apple apples_array [100];
	int number_of_bombs;
	int number_of_apples;
};

void create_frame (int row , int col);
void continue_way(snake& state);
snake move_snake_1(snake & situation , char command );
snake move_snake_2(snake & situation , char command);
void print_screen(snake s_1 , snake s_2 , playground yard);
playground add_apple( playground& yard, snake s_1 , snake s_2);
playground add_bomb( playground& yard, snake s_1, snake s_2);
void checkforloss(snake s , playground yard, int snake_number);
void add_length(snake &s, playground &yard);
void init_snake(snake & s ,int length , int starting_x , int starting_y);
int intersect(snake s_1 , snake s_2);
